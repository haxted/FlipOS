#include "uart.h"

// Raspberry Pi 3 PL011 UART MMIO
#define UART0_BASE 0x3F201000

#define UART0_DR   (*(volatile uint32_t*)(UART0_BASE + 0x00))
#define UART0_FR   (*(volatile uint32_t*)(UART0_BASE + 0x18))
#define UART0_IBRD (*(volatile uint32_t*)(UART0_BASE + 0x24))
#define UART0_FBRD (*(volatile uint32_t*)(UART0_BASE + 0x28))
#define UART0_LCRH (*(volatile uint32_t*)(UART0_BASE + 0x2C))
#define UART0_CR   (*(volatile uint32_t*)(UART0_BASE + 0x30))
#define UART0_IMSC (*(volatile uint32_t*)(UART0_BASE + 0x38))

// Mini delay
static void delay(int count) {
    for (volatile int i = 0; i < count; i++) asm volatile("nop");
}

void uart_init(void) {
    // Disable UART0
    UART0_CR = 0;

    // Setup baud rate 115200
    UART0_IBRD = 1;
    UART0_FBRD = 40;

    // 8 bits, no parity, 1 stop bit
    UART0_LCRH = (3 << 5);

    // Enable UART0, TX, RX
    UART0_CR = (1 << 0) | (1 << 8) | (1 << 9);
}

void uart_putc(char c) {
    // Wait until TX FIFO not full
    while(UART0_FR & (1 << 5));
    UART0_DR = c;
}

void uart_puts(const char* s) {
    while(*s) uart_putc(*s++);
}