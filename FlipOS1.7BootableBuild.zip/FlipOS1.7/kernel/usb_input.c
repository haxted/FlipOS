#include "usb_input.h"
#include "uart.h"

// NOTE: Replace USB_BASE with your board's actual MMIO address
#define USB_BASE 0x3F980000

// Simple placeholders for host controller registers
#define USB_CMD    0x00
#define USB_STATUS 0x04

mouse_t usb_mouse = {0,0,0};

// Low-level MMIO access
static inline uint32_t usb_read(uint32_t offset) {
    volatile uint32_t* ptr = (volatile uint32_t*)(USB_BASE + offset);
    return *ptr;
}

static inline void usb_write(uint32_t offset, uint32_t val) {
    volatile uint32_t* ptr = (volatile uint32_t*)(USB_BASE + offset);
    *ptr = val;
}

// Initialize USB controller
void usb_input_init(void) {
    uart_puts("USB driver init...\n");

    // Reset USB controller
    usb_write(USB_CMD, 0x00000001);
    // wait for reset done (poll STATUS)
    while(usb_read(USB_STATUS) & 0x1);

    uart_puts("USB host controller reset complete\n");

    // TODO: Enumerate devices (keyboard + mouse)
    // For now, we assume 1 keyboard + 1 mouse are connected
}

// Poll keyboard: returns ASCII character or 0
char usb_keyboard_getc(void) {
    // TODO: Poll the USB endpoint of keyboard
    // read scancode, convert to ASCII
    // For now, returns 0
    return 0;
}

// Poll mouse: update usb_mouse struct
void usb_mouse_poll(void) {
    // TODO: Poll USB mouse endpoint
    // read delta X/Y, buttons
    // update usb_mouse.x, usb_mouse.y, usb_mouse.buttons
}