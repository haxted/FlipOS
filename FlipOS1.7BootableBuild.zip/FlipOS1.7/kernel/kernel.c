#include "uart.h"
#include "string.h"
#include "usb_input.h"

// Minimal CLI buffer
#define CMD_BUF_SIZE 64
char cmd_buffer[CMD_BUF_SIZE];
int cmd_pos = 0;

void cli_init(void) {
    uart_puts("CLI initialized\n");
    cmd_pos = 0;
}

void cli_handle_input(char c) {
    if(c == '\n' || c == '\r') {
        cmd_buffer[cmd_pos] = 0; // terminate
        uart_puts("\nCommand: ");
        uart_puts(cmd_buffer);
        uart_puts("\n");
        // Example commands
        if(strcmp(cmd_buffer, "help") == 0) {
            uart_puts("Available: help, echo <text>\n");
        } else if(strncmp(cmd_buffer, "echo ", 5) == 0) {
            uart_puts(cmd_buffer + 5);
            uart_puts("\n");
        } else {
            uart_puts("Unknown command\n");
        }
        cmd_pos = 0;
    } else if(c == 8 || c == 127) {
        if(cmd_pos > 0) cmd_pos--;
    } else if(cmd_pos < CMD_BUF_SIZE - 1) {
        cmd_buffer[cmd_pos++] = c;
    }
}

void kernel_main(void) {
    uart_init();
    uart_puts("=== FlipOS Boot ===\n");

    // ---------------- USB Integration ----------------
    usb_input_init();          // initialize USB host
    uart_puts("USB keyboard+mouse ready\n");

    cli_init();

    // ---------------- Main loop ----------------
    while(1) {
        // Keyboard polling
        char c = usb_keyboard_getc();
        if(c) {
            uart_putc(c);          // echo character
            cli_handle_input(c);   // handle CLI input
        }

        // Mouse polling
        usb_mouse_poll();
        // usb_mouse.x, usb_mouse.y, usb_mouse.buttons are available
        // optional debug:
        // uart_puts("Mouse moved\n");
    }
}