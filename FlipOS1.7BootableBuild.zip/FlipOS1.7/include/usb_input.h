#pragma once
#include <stdint.h>

typedef struct {
    int x;
    int y;
    int buttons;  // bitmask: 1=left, 2=right, 4=middle
} mouse_t;

extern mouse_t usb_mouse;

// Initialize USB host controller and enumerate devices
void usb_input_init(void);

// Poll keyboard, return ASCII character or 0 if none
char usb_keyboard_getc(void);

// Poll mouse and update usb_mouse struct
void usb_mouse_poll(void);