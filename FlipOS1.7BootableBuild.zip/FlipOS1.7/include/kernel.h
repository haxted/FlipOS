#pragma once
#include <stdint.h>

// ---------------- Kernel core -----------------

// Entry point called by boot.S
void kernel_main(void);

// Optional: Kernel banner
void kernel_banner(void);

// ---------------- CLI -----------------
void cli_init(void);
void cli_handle_input(char c);

// ---------------- Utility -----------------
void panic(const char *msg);

// ---------------- Future driver API -----------------

// Register a function that gets polled each loop
typedef void (*driver_poll_t)(void);
void register_driver_poll(driver_poll_t poll_func);